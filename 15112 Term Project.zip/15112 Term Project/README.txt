Hi there!
Welcome to 112 joyride!

Project Description: 
Based on the popular 2011 game Jetpack joyride, the user continuously jumps in the air to dodge obstacles, collect coins for points, and obtain powerups. The goal: see how long you can last and how far you can go!


How to run:
Open the Jetpack Joyride.py file, and just running that code should be enough! Do keep all the pictures, sprites in the same folder as the I do apologize for the inconvenience that I cause for putting all my code into one file.

Libraries:
No external libraries used, just modules we used in class like cmu graphics.

Shortcuts + Commands:
There are none, so sorry about that. The levels just get progressively harder as the players progress, and that is about it. All levels are playable thanks to my backtracking AI making sure they are.